<?php
/**
 *
 * UpdatesMigration View
 *
 * @package	VirtueMart
 * @subpackage UpdatesMigration
 * @author Max Milbers
 * @link https://virtuemart.net
 * @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * @version $Id: view.html.php 11210 2025-10-20 17:01:08Z Milbo $
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

/**
 * HTML View class for maintaining the Installation. Updating of the files and imports of the database should be done here
 *
 * @package	VirtueMart
 * @subpackage UpdatesMigration
 * @author Max Milbers
 */
class VirtuemartViewUpdatesMigration extends VmViewAdmin {

	function display($tpl = null) {

		$latestVersion = vRequest::getVar('latestverison', '');

		JToolbarHelper::title(vmText::_('COM_VIRTUEMART_UPDATE_MIGRATION'), 'head vm_config_48');

		$this->assignRef('latestVersion', $latestVersion);

		$freshInstall = vRequest::getInt('redirectedToInstallVM',0);
		if($freshInstall){
			$this->setLayout('install');
		}

		$nosafepathcheck = vRequest::getInt('nosafepathcheck',0);
		if($nosafepathcheck){
			VmConfig::$installed = false;
		}
		//For uncached file permissions
		clearstatcache();
		vmLanguage::loadJLang('com_virtuemart_config');
		parent::display($tpl);
	}

	public function renderTaskButton($task, $descr, $extra='', $type ='a'){

		$link= JRoute::_('index.php?option=com_virtuemart&view=updatesmigration&task='.$task.'&'.vRequest::getFormToken().'=1'.$extra );
		$html = '<div class="icon">';
		if($type=='a'){
			//$html .= '<'.$type.' onclick="if(!confirm(\''.addslashes( vmText::_($descr.'_CONFIRM_JS') ).'\', \''.$link.'\'));">';
			$html .= '<'.$type.' class="vmjs-confirm" data-url="'.$link.'" data-query="'.vmText::_($descr.'_CONFIRM_JS').'" >';
		} else {
			$html .= '<'.$type.' class="vmjs-confirm" data-task="'.$task.'" data-query="'.vmText::_($descr.'_CONFIRM_JS').'" >';
		}


		$html .= '<span class="vmicon48"></span>';
		$html .= '<br />'.vmText::_($descr).'</'.$type.'></div>';
		return $html;
	}

	function writePathLines($folders){
		$style = 'text-align:left;margin-left:20px;';
		$result = '<div class="vmquote" style="'.$style.'">';
		$result .='<table>';
		foreach( $folders as $dir ) {
			$result .= '<tr>';
			$result .= '<td>'.$dir . '</td>';
			$result .= '<td>';
			//$result .= JFolder::exists( $dir )

			$c = 'red';
			$t = 'COM_VM_FNOTEXISTS';
			$p = '';
			if(!empty($dir)){
				if($ex = JFolder::exists( $dir )){
					$c = 'green';
					$t = 'COM_VM_FEXISTS';
					$p = substr(decoct(fileperms($dir)),2);
				}
			}

			$result .= '<span style="font-weight:bold;color:'.$c.';">'.vmText::_($t).'</span>';
			//? '<span style="font-weight:bold;color:green;">'.vmText::_('COM_VM_FEXISTS').'</span>'
			//: '<span style="font-weight:bold;color:red;">'.vmText::_('COM_VM_FNOTEXISTS').'</span>';
			$result .= '</td><td>';
			if(is_writable( $dir )){
				$c = 'green';
				$t = 'COM_VIRTUEMART_WRITABLE';

			} else {
				$c = 'red';
				$t = 'COM_VIRTUEMART_UNWRITABLE';

			}
			$result .= '<span style="font-weight:bold;color:'.$c.';">'.vmText::_($t).'</span>';
			/*$result .= is_writable( $dir )
			? '<span style="font-weight:bold;color:green;">'.vmText::_('COM_VIRTUEMART_WRITABLE').'</span>'
			: '<span style="font-weight:bold;color:red;">'.vmText::_('COM_VIRTUEMART_UNWRITABLE').'</span>';*/
			$result .= '<td>'.$p . '</td>';
			$result .= '</td></tr>';
		}
		$result .= '</table></div>';
		return $result;
	}
}
// pure php no closing tag
